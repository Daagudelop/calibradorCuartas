/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package poo.totxt;
 import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

/**
 *
 * @author Julian
 */
public class ToTXT {
//clase main donde se invoca al esciba
    public static void main(String[] args) {
        String path = "C:\\Users\\Julian\\Desktop\\pruebita.txt";
        Escriba escritor = new Escriba(path);
        
        escritor.escribe("If(){\n}");
    }
}
