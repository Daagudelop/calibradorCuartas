/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.totxt;

 import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class Escriba {
    // Esta clase crea y sobre escribe un archivo de texto
    private String Path;
    //private String TXT;
    
    public Escriba( String path) {
        //asigna un path donde crear al archivo
    this.Path = path;
    }
    
    public void escribe(String texto){
        
        //Usa magia para colocar el texto del arg texto en el archivo.
try {
      FileWriter myWriter = new FileWriter(this.Path);
      myWriter.write(texto);
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    }
}
    
    
    
    
    

